function copiarRazaoSocial() {
	$('[name="nomefantasia"]').val($('[name="razaosocial"]').val());
}