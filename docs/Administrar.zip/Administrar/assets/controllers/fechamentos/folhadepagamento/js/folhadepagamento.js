$(function(){
	$('#idCedente').chosen({
    	placeholder_text_single : 'Selecione o Cedente'
	});
	
	$('#idParametro').chosen({
    	placeholder_text_single : 'Selecione a Atividade'
	});
});


