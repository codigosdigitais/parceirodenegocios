$(function(){
	$('#idCliente').chosen({
    	placeholder_text_single : 'Selecione o Cliente'
	});
	
	$('#idFuncionario').chosen({
    	placeholder_text_single : 'Selecione o Cliente'
	});
});


