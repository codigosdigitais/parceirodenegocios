$(function(){
	$('#idAdministrador').chosen({
    	placeholder_text_single : 'Selecione uma Opção'
	});
});

