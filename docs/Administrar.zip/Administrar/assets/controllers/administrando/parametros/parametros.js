$(function(){
	$('#tipo_parametro').chosen({
    	placeholder_text_single : 'Selecione o Parâmetro'
	});

});

